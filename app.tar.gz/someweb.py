import sys
if 'pyodide' in sys.modules:
    import micropip
    micropip.install('pillow')
    print(micropip.install(keep_going=True))